require 'puppet/parser/parser'
require 'puppet/parser/compiler'
require 'puppet/resource/type_collection'

