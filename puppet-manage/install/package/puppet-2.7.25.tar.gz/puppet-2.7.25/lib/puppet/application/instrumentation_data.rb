require 'puppet/application/indirection_base'

class Puppet::Application::Instrumentation_data < Puppet::Application::IndirectionBase
end
