require 'puppet/application/face_base'

class Puppet::Application::Help < Puppet::Application::FaceBase
end
